export function getBaseUri(parent) {
    return globalThis.document.baseURI;
}
